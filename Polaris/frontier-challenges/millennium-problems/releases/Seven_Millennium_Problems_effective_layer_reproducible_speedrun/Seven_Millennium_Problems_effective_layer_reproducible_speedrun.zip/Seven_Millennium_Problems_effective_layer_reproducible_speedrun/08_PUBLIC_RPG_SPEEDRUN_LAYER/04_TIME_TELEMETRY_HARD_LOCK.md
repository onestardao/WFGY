# Time Telemetry Hard Lock

Problem:
AI often miscalculates elapsed time when it tries to do time arithmetic mentally.

Rule:
Do not calculate elapsed time by natural-language reasoning.

Use runtime clock or system time.

Required variables:
START_EPOCH_SECONDS
START_TIME_TEXT
END_EPOCH_SECONDS
END_TIME_TEXT
ELAPSED_SECONDS
ELAPSED_HH_MM_SS

Reference Python logic:
import time
import datetime

start_epoch = time.time()
start_text = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")

# run work here

end_epoch = time.time()
end_text = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")
elapsed_seconds = max(0, int(round(end_epoch - start_epoch)))
elapsed_hhmmss = str(datetime.timedelta(seconds=elapsed_seconds))

Hard fail if:
- START_TIME is missing
- END_TIME is missing
- ELAPSED_SECONDS is missing
- ELAPSED_HH_MM_SS is missing
- elapsed is guessed rather than computed
