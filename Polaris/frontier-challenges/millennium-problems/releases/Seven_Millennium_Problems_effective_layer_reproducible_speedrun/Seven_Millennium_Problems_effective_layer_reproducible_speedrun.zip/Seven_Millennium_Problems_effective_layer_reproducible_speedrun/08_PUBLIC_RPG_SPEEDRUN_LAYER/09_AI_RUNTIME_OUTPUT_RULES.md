# AI Runtime Output Rules

The package is ASCII-safe.
Do not place raw emoji in stored files.

Runtime visible human-readable output may expand aliases:
[EMOJI_TIME]
[EMOJI_START]
[EMOJI_END]
[EMOJI_BATTLE]
[EMOJI_AUDIT]
[EMOJI_PASS]
[EMOJI_WARN]
[EMOJI_TARGET]
[EMOJI_PACKAGE]

Machine-readable output must keep aliases or plain ASCII.

Visible output may use actual emoji only at runtime.
