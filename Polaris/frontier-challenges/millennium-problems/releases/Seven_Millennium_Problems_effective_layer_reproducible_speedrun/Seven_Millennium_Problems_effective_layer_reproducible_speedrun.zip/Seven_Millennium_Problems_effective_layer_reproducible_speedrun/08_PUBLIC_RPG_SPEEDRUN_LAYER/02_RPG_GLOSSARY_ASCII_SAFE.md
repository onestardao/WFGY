# RPG Glossary

Engineering term: ER score
RPG term: main boss HP clear meter
Public meaning: external review ledger completeness score.

Engineering term: strict_debt_cells_open
RPG term: open escape gates
Public meaning: number of tracked strict review debt cells still open.

Engineering term: theorem debt
RPG term: proof-route debt
Public meaning: remaining defined obligation before the route is review-ready.

Engineering term: formal_paper_candidate_debt
RPG term: missing pages in the official strategy book
Public meaning: debt blocking conversion into a paper-style candidate.

Engineering term: lean_no_sorry_route_debt
RPG term: broken bridges on the road to the machine temple
Public meaning: route debt before Lean no-sorry formalization.

Engineering term: machine_checked_no_sorry_file_count
RPG term: final temple stamp count
Public meaning: actual machine-checked Lean no-sorry files. In this package it remains 0.

Engineering term: Blackfan audit
RPG term: dark referee attack
Public meaning: adversarial review of escape routes and fake closure.

Engineering term: ER_STRICT_DEBT_ZERO_READY_FOR_MACHINE_FORMALIZATION
RPG term: seven bosses cleared the judgment arena; the machine temple gate is unlocked
Public meaning: strict-debt-zero ER state, ready for separate machine formalization.
