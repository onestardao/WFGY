@echo off
setlocal
cd /d "%~dp0"
echo Running Seven Millennium Problems RPG speedrun...
python tools\run_public_rpg_speedrun.py --root . --summary-json PUBLIC_RPG_RUN_SUMMARY.json
if errorlevel 1 (
  echo.
  echo SPEEDRUN CHECK REQUIRED.
  pause
  exit /b 1
)
echo.
echo SPEEDRUN PASS.
pause
