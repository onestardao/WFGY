#!/usr/bin/env python3
"""
Two-Way Official Statement Validation Data Validator.

This validator checks public validation data only.
It does not run or expose the internal compiler engine.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List, Tuple

EXPECTED_PROBLEMS = ["PNP", "RH", "BSD", "HODGE", "NS", "YM", "PC"]

REQUIRED_GLOBAL_FILES = [
    "README.md",
    "TWO_WAY_VALIDATION_DATA_SPEC.md",
    "ALL7_OFFICIAL_STATEMENT_PAYLOAD_INDEX.tsv",
    "ALL7_OFFICIAL_TO_NATIVE_COVERAGE_MATRIX.tsv",
    "ALL7_NATIVE_TO_OFFICIAL_COVERAGE_MATRIX.tsv",
    "ALL7_TWO_WAY_STATEMENT_VALIDATION_REPORT.json",
]

REQUIRED_PROBLEM_FILES = [
    "00_OFFICIAL_STATEMENT_PAYLOAD.md",
    "01_OFFICIAL_TO_NATIVE_COVERAGE.tsv",
    "02_NATIVE_CORE_STATEMENT_RECEIPT.md",
    "03_NATIVE_TO_OFFICIAL_COVERAGE.tsv",
    "04_TWO_WAY_VALIDATION_REPORT.json",
    "05_FINAL_OFFICIAL_THEOREM_OBJECT_RECEIPT.md",
]


def find_validation_dir(root: Path) -> Path | None:
    direct = root / "10_OFFICIAL_STATEMENT_TWO_WAY_VALIDATION"
    if direct.exists():
        return direct
    for p in root.rglob("10_OFFICIAL_STATEMENT_TWO_WAY_VALIDATION"):
        if p.is_dir():
            return p
    return None


def load_json(path: Path) -> Dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def read_tsv(path: Path) -> List[Dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8", newline="") as f:
            return list(csv.DictReader(f, delimiter="\t"))
    except Exception:
        return []


def validate_problem(pdir: Path, pid: str) -> Tuple[bool, List[str]]:
    failures: List[str] = []
    for filename in REQUIRED_PROBLEM_FILES:
        if not (pdir / filename).exists():
            failures.append("missing_" + filename)

    report = load_json(pdir / "04_TWO_WAY_VALIDATION_REPORT.json")
    checks = {
        "internal_compiler_engine_included": False,
        "official_statement_payload_exists": True,
        "unmapped_official_clauses": 0,
        "unmapped_native_claims": 0,
        "official_statement_intake_debt": 0,
        "two_way_statement_validation_debt": 0,
        "statement_tag_only_detected": False,
        "receipt_only_detected": False,
        "theorem_drift_detected": False,
        "two_way_statement_validation_status": "PASS",
    }
    for key, expected in checks.items():
        if report.get(key) != expected:
            failures.append(f"{key}_expected_{expected}_got_{report.get(key)}")
    if str(report.get("official_to_native_clause_coverage")) != "100%":
        failures.append("official_to_native_clause_coverage_not_100_percent")
    if str(report.get("native_to_official_clause_coverage")) != "100%":
        failures.append("native_to_official_clause_coverage_not_100_percent")
    if int(report.get("official_statement_clause_count", 0) or 0) <= 0:
        failures.append("official_statement_clause_count_not_positive")
    if int(report.get("native_receipt_claim_count", 0) or 0) <= 0:
        failures.append("native_receipt_claim_count_not_positive")

    off_rows = read_tsv(pdir / "01_OFFICIAL_TO_NATIVE_COVERAGE.tsv")
    ret_rows = read_tsv(pdir / "03_NATIVE_TO_OFFICIAL_COVERAGE.tsv")
    if not off_rows:
        failures.append("official_to_native_coverage_empty")
    if not ret_rows:
        failures.append("native_to_official_coverage_empty")
    for row in off_rows:
        if row.get("coverage_status") != "COVERED" or str(row.get("debt")) != "0":
            failures.append("official_to_native_bad_row")
            break
    for row in ret_rows:
        if row.get("coverage_status") != "COVERED" or str(row.get("debt")) != "0":
            failures.append("native_to_official_bad_row")
            break

    return (not failures), failures


def run(root: Path) -> int:
    vdir = find_validation_dir(root)
    if vdir is None:
        print("TWO_WAY_STATEMENT_VALIDATION_RESULT: CHECK_REQUIRED")
        print("reason: missing 10_OFFICIAL_STATEMENT_TWO_WAY_VALIDATION")
        return 1

    failures: List[str] = []
    for filename in REQUIRED_GLOBAL_FILES:
        if not (vdir / filename).exists():
            failures.append("missing_global_" + filename)

    global_report = load_json(vdir / "ALL7_TWO_WAY_STATEMENT_VALIDATION_REPORT.json")
    global_checks = {
        "internal_compiler_engine_included": False,
        "ALL7_TWO_WAY_STATEMENT_VALIDATION_PASS": True,
        "ALL7_official_statement_intake_debt": 0,
        "ALL7_two_way_statement_validation_debt": 0,
        "problem_count": 7,
        "FINAL_STATUS": "OFFICIAL_STATEMENT_TWO_WAY_VALIDATION_ALL7_PASS",
    }
    for key, expected in global_checks.items():
        if global_report.get(key) != expected:
            failures.append(f"global_{key}_expected_{expected}_got_{global_report.get(key)}")

    print("Two-Way Official Statement Validation Data Validator")
    for pid in EXPECTED_PROBLEMS:
        ok, problem_failures = validate_problem(vdir / pid, pid)
        print(f"{pid}: {'PASS' if ok else 'CHECK_REQUIRED'}")
        if not ok:
            failures.extend([pid + ":" + x for x in problem_failures])

    if failures:
        print("ALL7_TWO_WAY_STATEMENT_VALIDATION_PASS: false")
        print("FINAL_STATUS: CHECK_REQUIRED")
        for item in failures:
            print("failure:", item)
        return 1

    print("ALL7_TWO_WAY_STATEMENT_VALIDATION_PASS: true")
    print("ALL7_official_statement_intake_debt: 0")
    print("ALL7_two_way_statement_validation_debt: 0")
    print("FINAL_STATUS: OFFICIAL_STATEMENT_TWO_WAY_VALIDATION_ALL7_PASS")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="Package root directory after extraction.")
    args = parser.parse_args()
    return run(Path(args.root))


if __name__ == "__main__":
    raise SystemExit(main())
