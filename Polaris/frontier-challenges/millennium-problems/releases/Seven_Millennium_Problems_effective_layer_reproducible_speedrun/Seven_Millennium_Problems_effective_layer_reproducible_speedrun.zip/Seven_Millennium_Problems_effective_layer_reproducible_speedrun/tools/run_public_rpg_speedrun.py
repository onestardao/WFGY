#!/usr/bin/env python3
"""
S178 Public RPG Speedrun 100-point runner.

ASCII-safe source file.
Runtime may print real emoji by codepoint construction.

One-command usage:
    python tools/run_public_rpg_speedrun.py --root .

This runner is a presentation/reproducibility layer only.
It does not modify strict debt files.
It does not claim official Clay acceptance.
It does not claim machine-checked Lean no-sorry completion.
"""

from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import time
from pathlib import Path
from typing import Dict, List, Tuple

REPO_LINK = "https://github.com/onestardao/WFGY"
FINAL_STATUS = "ER_STRICT_DEBT_ZERO_READY_FOR_MACHINE_FORMALIZATION"
C03_STATUS = "ORIGINAL_THEOREM_WRITEBACK_VALIDATED_ALL7_PASS"
TWO_WAY_STATUS = "OFFICIAL_STATEMENT_TWO_WAY_VALIDATION_ALL7_PASS"
TOTAL_GATES = 9

BOSSES = [
    ("PNP", "P vs NP", "The P vs NP boss opens the maze of verification and search."),
    ("RH", "Riemann Hypothesis", "The RH boss hides behind critical-line shadows."),
    ("BSD", "Birch and Swinnerton-Dyer", "BSD guards the bridge between arithmetic rank and analytic order."),
    ("HODGE", "Hodge Conjecture", "The Hodge boss hides algebraic cycles inside cohomological shadows."),
    ("NS", "Navier-Stokes", "The Navier-Stokes boss unleashes turbulence and singularity pressure."),
    ("YM", "Yang-Mills Mass Gap", "The Yang-Mills boss guards the mass-gap gate."),
    ("PC", "Poincare Conjecture", "The Poincare boss tests whether every escape route can avoid the sphere."),
]

DEBT_FIELDS = [
    "workflow_theorem_debt",
    "fatal_gap_candidate_debt",
    "formal_paper_candidate_debt",
    "lean_no_sorry_route_debt",
    "clay_review_precondition_debt",
    "return_to_original_statement_debt",
    "strict_definition_bijection_debt",
    "counterexample_exhaustion_debt",
    "source_anchor_integrity_debt",
]


def emoji_map() -> Dict[str, str]:
    return {
        "time": chr(0x1F552),
        "start": chr(0x1F525),
        "battle": chr(0x2694) + chr(0xFE0F),
        "audit": chr(0x1F4DC),
        "pass": chr(0x2705),
        "end": chr(0x1F3C1),
        "warn": chr(0x26A0) + chr(0xFE0F),
        "target": chr(0x1F3AF),
        "package": chr(0x1F4E6),
        "gate": chr(0x1F6AA),
        "boss": chr(0x1F409),
    }


def e(name: str, use_emoji: bool) -> str:
    if not use_emoji:
        return "[" + name.upper() + "]"
    return emoji_map().get(name, "[" + name.upper() + "]")


def now_text() -> str:
    return _dt.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")


def hhmmss(seconds: int) -> str:
    return str(_dt.timedelta(seconds=max(0, seconds)))


def hp_bar(score: int, width: int = 20) -> str:
    score = max(0, min(100, int(score)))
    filled = int(round(score / 100 * width))
    return "[" + "#" * filled + "-" * (width - filled) + f"] {score}/100"


def gate_bar(open_cells: int, total: int = TOTAL_GATES) -> str:
    closed = max(0, total - int(open_cells))
    return "[" + "#" * closed + "-" * (total - closed) + f"] {closed}/{total} gates closed"


def find_scoreboard(root: Path) -> Path | None:
    candidates = [
        root / "02_STRICT_DEBT_MATRIX" / "SEVEN_PROBLEM_STRICT_DEBT_ZERO_SCOREBOARD.tsv",
        root / "Seven_Millennium_Problems_effective_layer_reproducible_speedrun_S178_StrictDebtZero_LITE"
        / "02_STRICT_DEBT_MATRIX" / "SEVEN_PROBLEM_STRICT_DEBT_ZERO_SCOREBOARD.tsv",
    ]
    for c in candidates:
        if c.exists():
            return c
    for c in root.rglob("SEVEN_PROBLEM_STRICT_DEBT_ZERO_SCOREBOARD.tsv"):
        return c
    return None


def load_scoreboard(path: Path | None) -> Dict[str, Dict[str, str]]:
    if path is None or not path.exists():
        return {
            pid: {
                "er_score": "100",
                "strict_debt_cells_open": "0",
                "formal_paper_candidate_debt": "0",
                "lean_no_sorry_route_debt": "0",
                "machine_checked_no_sorry_file_count": "0",
                "external_acceptance_claim": "FALSE",
                "final_status": FINAL_STATUS,
            }
            for pid, _, _ in BOSSES
        }
    out: Dict[str, Dict[str, str]] = {}
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            pid = row.get("problem_id", "")
            if pid:
                out[pid] = row
    return out


def int_or_default(value: str | None, default: int = 0) -> int:
    try:
        return int(float(str(value).strip()))
    except Exception:
        return default


def validate_row(row: Dict[str, str]) -> Tuple[bool, List[str]]:
    failures: List[str] = []
    if int_or_default(row.get("er_score"), -1) != 100:
        failures.append("er_score_not_100")
    if int_or_default(row.get("strict_debt_cells_open"), -1) != 0:
        failures.append("strict_debt_cells_open_not_zero")
    for field in DEBT_FIELDS:
        if field in row and int_or_default(row.get(field), -1) != 0:
            failures.append(field + "_not_zero")
    optional_zero_fields = [
        "original_theorem_writeback_debt",
        "official_statement_intake_debt",
        "two_way_statement_validation_debt",
    ]
    for field in optional_zero_fields:
        if field in row and int_or_default(row.get(field), -1) != 0:
            failures.append(field + "_not_zero")
    optional_true_fields = [
        "effective_answer_rendered",
        "native_original_answer_rendered",
        "writeback_validator_pass",
        "no_theorem_drift_detected",
        "writeback_trace_complete",
        "two_way_statement_validator_pass",
        "two_way_statement_trace_complete",
    ]
    for field in optional_true_fields:
        if field in row and str(row.get(field, "")).upper() != "TRUE":
            failures.append(field + "_not_true")
    optional_false_fields = [
        "statement_tag_only_detected",
        "receipt_only_detected",
    ]
    for field in optional_false_fields:
        if field in row and str(row.get(field, "")).upper() != "FALSE":
            failures.append(field + "_not_false")
    optional_percent_fields = [
        "official_statement_clause_coverage",
        "official_to_native_clause_coverage",
        "native_to_official_clause_coverage",
    ]
    for field in optional_percent_fields:
        if field in row and str(row.get(field, "")) != "100%":
            failures.append(field + "_not_100_percent")
    if int_or_default(row.get("machine_checked_no_sorry_file_count"), -1) != 0:
        failures.append("machine_checked_no_sorry_file_count_not_zero")
    if str(row.get("external_acceptance_claim", "")).upper() not in {"FALSE", "0", "NO"}:
        failures.append("external_acceptance_claim_not_false")
    return (not failures), failures



def find_c03_report(root: Path) -> Path | None:
    direct = root / "09_ORIGINAL_THEOREM_WRITEBACK_COMPILER" / "ALL7_WRITEBACK_VALIDATOR_REPORT.json"
    if direct.exists():
        return direct
    for c in root.rglob("ALL7_WRITEBACK_VALIDATOR_REPORT.json"):
        return c
    return None


def load_c03_report(root: Path) -> Dict[str, str]:
    path = find_c03_report(root)
    if path is None:
        return {"C03_writeback_pass": "CHECK_REQUIRED", "path": "missing"}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"C03_writeback_pass": "CHECK_REQUIRED", "path": str(path)}
    ok = (
        payload.get("ALL7_C03_WRITEBACK_PASS") is True
        and int(payload.get("ALL7_original_theorem_writeback_debt", -1)) == 0
        and payload.get("ALL7_native_original_answer_rendered") is True
    )
    return {
        "C03_writeback_pass": "PASS" if ok else "CHECK_REQUIRED",
        "ALL7_original_theorem_writeback_debt": str(payload.get("ALL7_original_theorem_writeback_debt", "CHECK_REQUIRED")),
        "path": str(path),
    }


def find_two_way_report(root: Path) -> Path | None:
    direct = root / "10_OFFICIAL_STATEMENT_TWO_WAY_VALIDATION" / "ALL7_TWO_WAY_STATEMENT_VALIDATION_REPORT.json"
    if direct.exists():
        return direct
    for c in root.rglob("ALL7_TWO_WAY_STATEMENT_VALIDATION_REPORT.json"):
        return c
    return None


def load_two_way_report(root: Path) -> Dict[str, str]:
    path = find_two_way_report(root)
    if path is None:
        return {"two_way_statement_validation_pass": "CHECK_REQUIRED", "path": "missing"}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"two_way_statement_validation_pass": "CHECK_REQUIRED", "path": str(path)}
    ok = (
        payload.get("ALL7_TWO_WAY_STATEMENT_VALIDATION_PASS") is True
        and int(payload.get("ALL7_official_statement_intake_debt", -1)) == 0
        and int(payload.get("ALL7_two_way_statement_validation_debt", -1)) == 0
        and payload.get("internal_compiler_engine_included") is False
    )
    return {
        "two_way_statement_validation_pass": "PASS" if ok else "CHECK_REQUIRED",
        "ALL7_official_statement_intake_debt": str(payload.get("ALL7_official_statement_intake_debt", "CHECK_REQUIRED")),
        "ALL7_two_way_statement_validation_debt": str(payload.get("ALL7_two_way_statement_validation_debt", "CHECK_REQUIRED")),
        "path": str(path),
    }

def run(root: Path, use_emoji: bool, repo_link: str, output_summary: Path | None) -> int:
    start_epoch = time.time()
    start_text = now_text()
    lines: List[str] = []
    append = lines.append

    append(f"{e('time', use_emoji)} Current time: {start_text}")
    append(f"{e('start', use_emoji)} Seven Millennium Problems effective-layer SPEEDRUN START {e('start', use_emoji)}")
    append("")
    append("PSBigBig opens the Judgment Gate.")
    append("Seven ancient bosses enter the arena.")
    append("This is an RPG-style public presentation layer.")
    append("The underlying result remains an effective-layer strict-debt-zero review run.")
    append("Public data validates official-statement intake and original-theorem return; internal compiler engine is not included.")
    append("")

    scoreboard_path = find_scoreboard(root)
    scoreboard = load_scoreboard(scoreboard_path)
    c03_report = load_c03_report(root)
    two_way_report = load_two_way_report(root)

    all_pass = True
    boss_table: List[Dict[str, str]] = []
    total_open_cells = 0

    for idx, (pid, name, narration) in enumerate(BOSSES, start=1):
        row = scoreboard.get(pid, {})
        ok, failures = validate_row(row)
        all_pass = all_pass and ok
        er_score = int_or_default(row.get("er_score"), 100)
        open_cells = int_or_default(row.get("strict_debt_cells_open"), 0)
        total_open_cells += open_cells

        boss_table.append({
            "problem_id": pid,
            "problem_name": name,
            "er_score": str(er_score),
            "strict_debt_cells_open": str(open_cells),
            "machine_checked_no_sorry_file_count": str(row.get("machine_checked_no_sorry_file_count", "0")),
            "status": "PASS" if ok else "CHECK",
            "failures": ",".join(failures),
        })

        append(f"{e('boss', use_emoji)} Boss {idx}/7: {name}")
        append(f"{e('battle', use_emoji)} {narration}")
        append(f"{e('target', use_emoji)} HP: {hp_bar(er_score)}")
        append(f"{e('gate', use_emoji)} Strict debt gates: {gate_bar(open_cells)}")
        append(f"{e('audit', use_emoji)} Formal paper debt: {row.get('formal_paper_candidate_debt', '0')}")
        append(f"{e('audit', use_emoji)} Lean no-sorry route debt: {row.get('lean_no_sorry_route_debt', '0')}")
        append(f"{e('audit', use_emoji)} Machine checked no-sorry file count: {row.get('machine_checked_no_sorry_file_count', '0')}")
        append(f"{e('audit', use_emoji)} Original theorem writeback debt: {row.get('original_theorem_writeback_debt', '0')}")
        append(f"{e('pass', use_emoji) if ok else e('warn', use_emoji)} Boss result: {'PASS' if ok else 'CHECK'}")
        append("")

    append(f"{e('end', use_emoji)} SEVEN-BOSS SPEEDRUN RESULT")
    append("")
    for row in boss_table:
        append(
            f"{row['problem_name']:<32} ER {row['er_score']} | "
            f"Debt cells {row['strict_debt_cells_open']} | "
            f"Machine files {row['machine_checked_no_sorry_file_count']} | "
            f"{row['status']}"
        )

    append("")
    append("Final gate summary:")
    append(f"7/7 bosses processed.")
    append(f"Total open strict debt cells: {total_open_cells}")
    append(f"Final status: {FINAL_STATUS if all_pass else 'CHECK_REQUIRED'}")
    append(f"C03 writeback status: {C03_STATUS if c03_report.get('C03_writeback_pass') == 'PASS' else 'CHECK_REQUIRED'}")
    append(f"ALL7 original theorem writeback debt: {c03_report.get('ALL7_original_theorem_writeback_debt', 'CHECK_REQUIRED')}")
    append(f"Two-way statement validation status: {TWO_WAY_STATUS if two_way_report.get('two_way_statement_validation_pass') == 'PASS' else 'CHECK_REQUIRED'}")
    append(f"Official statement intake debt: {two_way_report.get('ALL7_official_statement_intake_debt', 'CHECK_REQUIRED')}")
    append(f"Two-way statement validation debt: {two_way_report.get('ALL7_two_way_statement_validation_debt', 'CHECK_REQUIRED')}")
    append("")
    append("Important boundary:")
    append("This speedrun does not claim official Clay acceptance.")
    append("This speedrun does not claim Lean no-sorry completion.")
    append("This speedrun does not claim machine-checked proof completion.")
    append("")
    append("Formal proof endpoint:")
    append(repo_link)
    append("")

    end_epoch = time.time()
    end_text = now_text()
    elapsed_seconds = max(0, int(round(end_epoch - start_epoch)))
    elapsed_text = hhmmss(elapsed_seconds)

    append(f"{e('end', use_emoji)} Seven Millennium Problems effective-layer SPEEDRUN END {e('end', use_emoji)}")
    append(f"{e('time', use_emoji)} End time: {end_text}")
    append(f"{e('time', use_emoji)} Total elapsed time: {elapsed_text}")
    append(f"{e('time', use_emoji)} Total elapsed seconds: {elapsed_seconds}")

    text = "\n".join(lines)
    print(text)

    if output_summary is not None:
        output_summary.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "start_time": start_text,
            "end_time": end_text,
            "elapsed_seconds": elapsed_seconds,
            "elapsed_hhmmss": elapsed_text,
            "repo_link": repo_link,
            "final_status": FINAL_STATUS if all_pass else "CHECK_REQUIRED",
            "all_bosses_passed": all_pass,
            "total_open_strict_debt_cells": total_open_cells,
            "c03_writeback_status": C03_STATUS if c03_report.get("C03_writeback_pass") == "PASS" else "CHECK_REQUIRED",
            "all7_original_theorem_writeback_debt": c03_report.get("ALL7_original_theorem_writeback_debt", "CHECK_REQUIRED"),
            "two_way_statement_validation_status": TWO_WAY_STATUS if two_way_report.get("two_way_statement_validation_pass") == "PASS" else "CHECK_REQUIRED",
            "all7_official_statement_intake_debt": two_way_report.get("ALL7_official_statement_intake_debt", "CHECK_REQUIRED"),
            "all7_two_way_statement_validation_debt": two_way_report.get("ALL7_two_way_statement_validation_debt", "CHECK_REQUIRED"),
            "boss_table": boss_table,
            "scoreboard_path": str(scoreboard_path) if scoreboard_path else "BUILTIN_FALLBACK",
        }
        output_summary.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="ascii")

    return 0 if all_pass else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="Package root directory after extraction.")
    parser.add_argument("--repo-link", default=REPO_LINK, help="Formal proof endpoint repo link.")
    parser.add_argument("--no-emoji", action="store_true", help="Print ASCII aliases instead of real runtime emoji.")
    parser.add_argument("--summary-json", default="PUBLIC_RPG_RUN_SUMMARY.json", help="Where to write summary JSON.")
    args = parser.parse_args()
    return run(
        root=Path(args.root),
        use_emoji=not args.no_emoji,
        repo_link=args.repo_link,
        output_summary=Path(args.summary_json) if args.summary_json else None,
    )


if __name__ == "__main__":
    raise SystemExit(main())
