# Yang-Mills Existence and Mass Gap · Native Core Statement Receipt

## Public artifact boundary

This file is a public receipt for the native/effective route used by the package. It does not expose the internal compiler engine.

## Problem ID

```text
YM
```

## Native / effective route receipt phrase

```text
existence plus positive mass gap
```

## Native route claims tracked by validation data

| Native Claim | Name | Payload |
|---|---|---|
| N1 | Theory-construction payload | The native statement exposes the quantum Yang-Mills construction target. |
| N2 | Gauge/domain payload | The native route records R^4 and compact simple gauge group conditions. |
| N3 | Mass-gap payload | The native route records positive mass gap as the theorem target. |
| N4 | Formal theorem target receipt | The native route emits a theorem target object for later formalization. |
| N5 | Return payload | The native route maps back to the official YM statement. |

## Return validation meaning

This receipt is checked against the official-statement payload and the C03 original-native writeback answer.
