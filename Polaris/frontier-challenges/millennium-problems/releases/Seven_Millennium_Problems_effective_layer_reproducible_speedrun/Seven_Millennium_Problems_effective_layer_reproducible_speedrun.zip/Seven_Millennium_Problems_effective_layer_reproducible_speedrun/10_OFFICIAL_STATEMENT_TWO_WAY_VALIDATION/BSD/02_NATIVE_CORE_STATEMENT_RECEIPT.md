# Birch and Swinnerton-Dyer Conjecture · Native Core Statement Receipt

## Public artifact boundary

This file is a public receipt for the native/effective route used by the package. It does not expose the internal compiler engine.

## Problem ID

```text
BSD
```

## Native / effective route receipt phrase

```text
rank equals analytic order plus leading-term formula
```

## Native route claims tracked by validation data

| Native Claim | Name | Payload |
|---|---|---|
| N1 | Curve payload | The native statement exposes the elliptic-curve-over-Q object. |
| N2 | Rank/order coupling payload | The native route records the rank/order equality target. |
| N3 | Leading-term payload | The native route records the arithmetic invariant target. |
| N4 | Formal theorem target receipt | The native route emits a theorem target object for later formalization. |
| N5 | Return payload | The native route maps back to the official BSD statement. |

## Return validation meaning

This receipt is checked against the official-statement payload and the C03 original-native writeback answer.
