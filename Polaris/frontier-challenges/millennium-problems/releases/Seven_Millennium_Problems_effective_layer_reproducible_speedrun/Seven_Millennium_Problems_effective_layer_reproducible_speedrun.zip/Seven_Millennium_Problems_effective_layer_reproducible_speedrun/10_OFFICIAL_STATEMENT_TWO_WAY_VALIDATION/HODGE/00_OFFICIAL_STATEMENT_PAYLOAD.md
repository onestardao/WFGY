# Hodge Conjecture · Official Statement Payload

## Public artifact boundary

This file is public validation data only. It does not expose the internal compiler engine.

## Problem ID

```text
HODGE
```

## Domain

```text
Algebraic geometry
```

## Official target statement

```text
Every rational Hodge class on a smooth projective complex variety is a rational linear combination of algebraic cycle classes.
```

## Native / effective route receipt phrase

```text
rational Hodge classes are algebraic
```

## Official statement clauses

| Clause | Name | Payload |
|---|---|---|
| O1 | Smooth projective complex variety | The official payload preserves the geometric domain. |
| O2 | Rational Hodge class | The official payload preserves the source class type. |
| O3 | Algebraic cycle classes | The official payload preserves the target cycle-class object. |
| O4 | Rational linear combination | The official payload preserves rational-span closure. |
| O5 | No line-hit replacement | The native route must not replace exact algebraicity by a weaker nonzero-hit result. |

## Intake validation meaning

This payload is the public data object used to check that the package starts from an expanded official-statement target, not only from a statement label or receipt.
