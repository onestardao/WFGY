# Navier-Stokes Existence and Smoothness · Native Core Statement Receipt

## Public artifact boundary

This file is a public receipt for the native/effective route used by the package. It does not expose the internal compiler engine.

## Problem ID

```text
NS
```

## Native / effective route receipt phrase

```text
global regularity or finite-time singularity statement
```

## Native route claims tracked by validation data

| Native Claim | Name | Payload |
|---|---|---|
| N1 | Initial-data payload | The native statement exposes smooth divergence-free data. |
| N2 | Evolution payload | The native route records the incompressible Navier-Stokes flow target. |
| N3 | Regularity-decision payload | The native route records the global smoothness / breakdown alternative. |
| N4 | Formal theorem target receipt | The native route emits a theorem target object for later formalization. |
| N5 | Return payload | The native route maps back to the official NS statement. |

## Return validation meaning

This receipt is checked against the official-statement payload and the C03 original-native writeback answer.
