# Hodge Conjecture · Final Official Theorem Object Receipt

This file is public validation data only.

## Official target

```text
Every rational Hodge class on a smooth projective complex variety is a rational linear combination of algebraic cycle classes.
```

## Native/effective receipt

```text
rational Hodge classes are algebraic
```

## Validation receipt

```text
official_to_native_clause_coverage = 100%
native_to_official_clause_coverage = 100%
unmapped_official_clauses = 0
unmapped_native_claims = 0
statement_tag_only_detected = false
receipt_only_detected = false
theorem_drift_detected = false
two_way_statement_validation_status = PASS
```
