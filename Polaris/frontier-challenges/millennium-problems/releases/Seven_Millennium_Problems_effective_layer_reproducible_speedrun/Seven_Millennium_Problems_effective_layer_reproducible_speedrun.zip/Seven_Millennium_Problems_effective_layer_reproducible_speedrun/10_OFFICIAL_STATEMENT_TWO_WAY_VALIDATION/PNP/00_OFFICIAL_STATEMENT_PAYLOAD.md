# P vs NP · Official Statement Payload

## Public artifact boundary

This file is public validation data only. It does not expose the internal compiler engine.

## Problem ID

```text
PNP
```

## Domain

```text
Computational complexity
```

## Official target statement

```text
Decide whether every efficiently verifiable decision problem is also efficiently solvable.
```

## Native / effective route receipt phrase

```text
P = NP / P != NP decision problem
```

## Official statement clauses

| Clause | Name | Payload |
|---|---|---|
| O1 | Decision problems / languages | The official target concerns decision problems formalized as languages. |
| O2 | Efficient verification | The official target preserves polynomial-time verifiability / NP-side witness checking. |
| O3 | Efficient solving | The official target preserves deterministic polynomial-time solvability / P-side decision. |
| O4 | Equality-or-separation decision | The official target asks whether the two classes coincide or separate. |
| O5 | No replacement target | The native route must not replace P vs NP by a weaker benchmark, heuristic, or finite-instance task. |

## Intake validation meaning

This payload is the public data object used to check that the package starts from an expanded official-statement target, not only from a statement label or receipt.
