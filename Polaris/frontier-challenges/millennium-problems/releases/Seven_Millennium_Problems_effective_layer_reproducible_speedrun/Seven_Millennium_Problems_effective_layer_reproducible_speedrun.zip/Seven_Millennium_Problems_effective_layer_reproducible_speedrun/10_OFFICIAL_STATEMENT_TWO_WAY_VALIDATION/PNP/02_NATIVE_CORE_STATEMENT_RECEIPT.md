# P vs NP · Native Core Statement Receipt

## Public artifact boundary

This file is a public receipt for the native/effective route used by the package. It does not expose the internal compiler engine.

## Problem ID

```text
PNP
```

## Native / effective route receipt phrase

```text
P = NP / P != NP decision problem
```

## Native route claims tracked by validation data

| Native Claim | Name | Payload |
|---|---|---|
| N1 | Native language class payload | The native statement exposes the P/NP language-class payload. |
| N2 | Verifier-to-solver bridge payload | The native route records the verifier/solver comparison target. |
| N3 | Endpoint obstruction payload | The native route records the route slot that decides equality/separation without changing the target. |
| N4 | Formal theorem target receipt | The native route emits a theorem target object for later formalization. |
| N5 | Return payload | The native route maps back to the official P vs NP decision. |

## Return validation meaning

This receipt is checked against the official-statement payload and the C03 original-native writeback answer.
