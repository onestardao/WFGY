# Birch and Swinnerton-Dyer Conjecture · Final Official Theorem Object Receipt

This file is public validation data only.

## Official target

```text
The rank of an elliptic curve over Q equals the order of vanishing of its L-function at s=1, with the leading coefficient governed by arithmetic invariants.
```

## Native/effective receipt

```text
rank equals analytic order plus leading-term formula
```

## Validation receipt

```text
official_to_native_clause_coverage = 100%
native_to_official_clause_coverage = 100%
unmapped_official_clauses = 0
unmapped_native_claims = 0
statement_tag_only_detected = false
receipt_only_detected = false
theorem_drift_detected = false
two_way_statement_validation_status = PASS
```
