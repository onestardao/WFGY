# Navier-Stokes Existence and Smoothness · Official Statement Payload

## Public artifact boundary

This file is public validation data only. It does not expose the internal compiler engine.

## Problem ID

```text
NS
```

## Domain

```text
PDE / fluid mechanics
```

## Official target statement

```text
For smooth divergence-free initial data in three dimensions, decide global existence and smoothness of incompressible Navier-Stokes solutions, or exhibit breakdown.
```

## Native / effective route receipt phrase

```text
global regularity or finite-time singularity statement
```

## Official statement clauses

| Clause | Name | Payload |
|---|---|---|
| O1 | Three-dimensional setting | The official payload preserves the 3D incompressible fluid setting. |
| O2 | Smooth divergence-free initial data | The official payload preserves the initial-data class. |
| O3 | Navier-Stokes evolution | The official payload preserves the PDE evolution target. |
| O4 | Global smoothness or breakdown | The official payload preserves the regularity / singularity decision. |
| O5 | No finite simulation replacement | The native route must not replace the theorem by a numerical or bounded-time simulation. |

## Intake validation meaning

This payload is the public data object used to check that the package starts from an expanded official-statement target, not only from a statement label or receipt.
