# Birch and Swinnerton-Dyer Conjecture · Official Statement Payload

## Public artifact boundary

This file is public validation data only. It does not expose the internal compiler engine.

## Problem ID

```text
BSD
```

## Domain

```text
Arithmetic geometry
```

## Official target statement

```text
The rank of an elliptic curve over Q equals the order of vanishing of its L-function at s=1, with the leading coefficient governed by arithmetic invariants.
```

## Native / effective route receipt phrase

```text
rank equals analytic order plus leading-term formula
```

## Official statement clauses

| Clause | Name | Payload |
|---|---|---|
| O1 | Elliptic curve over Q | The official payload preserves elliptic curves over the rational numbers. |
| O2 | Algebraic rank | The official payload preserves the Mordell-Weil rank side. |
| O3 | Analytic order | The official payload preserves the order of vanishing of the L-function at s=1. |
| O4 | Leading coefficient invariants | The official payload preserves the arithmetic leading-term formula target. |
| O5 | No partial-rank replacement | The native route must not replace BSD by only one inequality or a finite family. |

## Intake validation meaning

This payload is the public data object used to check that the package starts from an expanded official-statement target, not only from a statement label or receipt.
