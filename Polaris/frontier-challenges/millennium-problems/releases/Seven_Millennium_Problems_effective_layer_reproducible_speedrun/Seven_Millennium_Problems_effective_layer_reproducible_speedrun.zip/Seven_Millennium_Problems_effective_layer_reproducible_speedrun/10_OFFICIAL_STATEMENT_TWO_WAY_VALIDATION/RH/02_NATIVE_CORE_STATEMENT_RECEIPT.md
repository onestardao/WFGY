# Riemann Hypothesis · Native Core Statement Receipt

## Public artifact boundary

This file is a public receipt for the native/effective route used by the package. It does not expose the internal compiler engine.

## Problem ID

```text
RH
```

## Native / effective route receipt phrase

```text
critical-line zero statement
```

## Native route claims tracked by validation data

| Native Claim | Name | Payload |
|---|---|---|
| N1 | Spectral zero payload | The native statement exposes nontrivial-zero data as the main object. |
| N2 | Critical-line invariant | The native route preserves the Re(s)=1/2 target. |
| N3 | Global coverage receipt | The native route records universal coverage rather than finite verification only. |
| N4 | Formal theorem target receipt | The native route emits a theorem target object for later formalization. |
| N5 | Return payload | The native route maps back to the official RH statement. |

## Return validation meaning

This receipt is checked against the official-statement payload and the C03 original-native writeback answer.
