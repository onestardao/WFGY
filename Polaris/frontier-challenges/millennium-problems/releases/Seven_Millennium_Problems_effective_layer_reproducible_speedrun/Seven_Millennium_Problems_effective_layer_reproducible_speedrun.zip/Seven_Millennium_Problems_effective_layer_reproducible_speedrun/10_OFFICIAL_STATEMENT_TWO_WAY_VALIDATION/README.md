# Official Statement Two-Way Validation Data

This folder publishes the data artifacts used for the official-statement two-way validation check.

It does not publish the internal compiler engine. It publishes only validation data and validator inputs.

Validation intent:

```text
official statement payload
-> native/effective route receipt
-> original theorem writeback receipt
-> two-way statement alignment report
```

The public check verifies that the package is not relying only on statement tags, receipts, or labels. It verifies that each official statement has an explicit payload, that the official-to-native coverage matrix is complete, that the native-to-official return matrix is complete, and that no theorem drift is detected.

Final expected status:

```text
OFFICIAL_STATEMENT_TWO_WAY_VALIDATION_ALL7_PASS
```
