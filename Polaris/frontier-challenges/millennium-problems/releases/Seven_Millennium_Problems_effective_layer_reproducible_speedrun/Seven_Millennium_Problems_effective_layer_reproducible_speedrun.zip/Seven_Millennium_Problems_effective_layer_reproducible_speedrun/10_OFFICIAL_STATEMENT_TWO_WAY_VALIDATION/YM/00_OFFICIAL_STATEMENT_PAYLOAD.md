# Yang-Mills Existence and Mass Gap · Official Statement Payload

## Public artifact boundary

This file is public validation data only. It does not expose the internal compiler engine.

## Problem ID

```text
YM
```

## Domain

```text
Mathematical physics
```

## Official target statement

```text
Construct nontrivial quantum Yang-Mills theory on R^4 for a compact simple gauge group and prove a positive mass gap.
```

## Native / effective route receipt phrase

```text
existence plus positive mass gap
```

## Official statement clauses

| Clause | Name | Payload |
|---|---|---|
| O1 | Quantum Yang-Mills construction | The official payload preserves construction of the quantum theory. |
| O2 | R^4 domain | The official payload preserves the four-dimensional Euclidean space setting. |
| O3 | Compact simple gauge group | The official payload preserves the gauge-group condition. |
| O4 | Positive mass gap | The official payload preserves the positive mass-gap target. |
| O5 | No classical-field replacement | The native route must not replace the quantum existence/mass-gap target by a classical field surrogate. |

## Intake validation meaning

This payload is the public data object used to check that the package starts from an expanded official-statement target, not only from a statement label or receipt.
