# Two-Way Validation Data Spec

This is a public data specification, not the internal compiler implementation.

The validator checks four public artifact classes:

1. official statement payloads
2. official-to-native coverage tables
3. native-to-official coverage tables
4. per-lane two-way validation reports

Required global result:

```text
ALL7_TWO_WAY_STATEMENT_VALIDATION_PASS = true
ALL7_official_statement_intake_debt = 0
ALL7_two_way_statement_validation_debt = 0
FINAL_STATUS = OFFICIAL_STATEMENT_TWO_WAY_VALIDATION_ALL7_PASS
```

Required per-lane checks:

```text
official_statement_payload_exists = true
official_statement_clause_count > 0
official_to_native_clause_coverage = 100%
native_to_official_clause_coverage = 100%
unmapped_official_clauses = 0
unmapped_native_claims = 0
statement_tag_only_detected = false
receipt_only_detected = false
theorem_drift_detected = false
two_way_statement_validation_status = PASS
```
