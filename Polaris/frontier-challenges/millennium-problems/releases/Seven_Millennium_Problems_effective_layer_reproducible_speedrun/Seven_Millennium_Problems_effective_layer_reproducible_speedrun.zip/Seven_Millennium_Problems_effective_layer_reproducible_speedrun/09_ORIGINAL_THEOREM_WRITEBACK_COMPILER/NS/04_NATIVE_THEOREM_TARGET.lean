-- C03 native theorem target stub for Navier-Stokes Existence and Smoothness
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.NS

-- theorem target:
-- For smooth divergence-free initial data in three dimensions, decide global existence and smoothness of incompressible Navier-Stokes solutions, or exhibit breakdown.

axiom native_theorem_target_NS : Prop

end WFGY.C03.NS
