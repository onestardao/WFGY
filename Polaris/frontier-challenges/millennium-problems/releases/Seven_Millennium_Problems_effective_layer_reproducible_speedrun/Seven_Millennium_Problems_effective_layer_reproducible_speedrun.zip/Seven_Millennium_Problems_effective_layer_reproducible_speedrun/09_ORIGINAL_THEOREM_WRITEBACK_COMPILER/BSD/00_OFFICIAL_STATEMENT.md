# Birch and Swinnerton-Dyer Conjecture · Official Statement Lock

## Problem ID

```text
BSD
```

## Domain

```text
Arithmetic geometry
```

## Official theorem target

```text
The rank of an elliptic curve over Q equals the order of vanishing of its L-function at s=1, with the leading coefficient governed by arithmetic invariants.
```

## Native target phrase

```text
rank equals analytic order plus leading-term formula
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
