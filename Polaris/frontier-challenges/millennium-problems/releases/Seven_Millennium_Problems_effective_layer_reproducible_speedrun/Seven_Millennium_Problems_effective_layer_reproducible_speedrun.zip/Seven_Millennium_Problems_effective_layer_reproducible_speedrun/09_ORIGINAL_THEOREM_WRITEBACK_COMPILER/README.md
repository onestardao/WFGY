# C03 Original Theorem Writeback Compiler

This folder adds the final writeback layer to the public speedrun package.

The earlier layers show that each lane reaches strict theorem-debt-zero status inside the packaged effective-layer validator. C03 performs the next step: it renders the debt-zero route back into the official problem language and validates that the rendered answer is tied to the original statement.

## C03 components

1. **Writeback Compiler**  
   Converts the effective-layer debt-zero ledger into an original-problem proof-candidate format.

2. **Writeback Validator**  
   Checks that the writeback covers the official statement clauses, maps ledger obligations to native clauses, preserves the return-to-original lock, and does not introduce theorem drift.

## Two answer versions per problem

Each problem folder contains two answer surfaces:

- `03A_EFFECTIVE_LAYER_ANSWER.md`  
  The validator-facing answer. It stays in the effective-layer ledger language.

- `03B_ORIGINAL_NATIVE_WRITEBACK_ANSWER.md`  
  The original-problem-facing answer. It translates the effective-layer closure back into the native theorem statement format.

The second file is the important public bridge: it is the piece that shows how the speedrun result is intended to be read back in the problem's own mathematical language.

## Final C03 status

The package-level C03 validator report is:

```text
ALL7_C03_WRITEBACK_PASS = true
ALL7_original_theorem_writeback_debt = 0
ALL7_native_original_answer_rendered = true
```

## Detailed 03B native writeback answers

Each problem folder contains `03B_ORIGINAL_NATIVE_WRITEBACK_ANSWER.md`. In this C03-expanded package, those files are not placeholder notes. They contain the official theorem target, native objects, clause-by-clause coverage, effective-to-native conversion trace, native proof-candidate route, formalization handoff invariants, and the C03 validator verdict.

The intended reading order for any single problem is:

```text
00_OFFICIAL_STATEMENT.md
01_CLAUSE_MAP.tsv
02_LEDGER_TO_PROOF_ROUTE_MAP.tsv
03A_EFFECTIVE_LAYER_ANSWER.md
03B_ORIGINAL_NATIVE_WRITEBACK_ANSWER.md
04_NATIVE_THEOREM_TARGET.lean
05_WRITEBACK_VALIDATOR_REPORT.json
```
