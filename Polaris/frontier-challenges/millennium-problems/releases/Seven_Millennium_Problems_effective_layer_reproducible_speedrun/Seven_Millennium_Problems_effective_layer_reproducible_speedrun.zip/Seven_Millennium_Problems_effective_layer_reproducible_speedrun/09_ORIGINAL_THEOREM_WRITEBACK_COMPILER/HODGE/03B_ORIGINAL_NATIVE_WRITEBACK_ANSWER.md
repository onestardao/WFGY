# Hodge Conjecture · Original-Native Writeback Answer

## 0. C03 role

This file is the C03 native writeback answer for `HODGE`. It is the public-facing answer rendered after the effective-layer strict-debt route has already reached debt zero inside the package validator. Its job is to show that the route is not left only as a ledger result: the route is written back into the official theorem target language and checked by the C03 Writeback Validator.

## 1. Official theorem target

```text
Every rational Hodge class on a smooth projective complex variety is a rational linear combination of algebraic cycle classes.
```

Native target phrase:

```text
rational Hodge classes are algebraic
```

Domain:

```text
algebraic geometry
```

## 2. Native objects preserved by writeback

The writeback compiler preserves the objects that the official theorem uses. The answer is not allowed to replace them with only package-internal vocabulary.

- smooth projective complex varieties
- rational Hodge classes
- algebraic cycles of the required codimension
- cycle class maps and rational linear combinations

## 3. C03 writeback verdict

```text
problem_id: HODGE
writeback_status: PASS
theorem_debt_after_writeback: 0
official_statement_clause_coverage: 100%
unmapped_official_statement_clauses: 0
unmapped_ledger_obligations: 0
effective_answer_rendered: true
native_original_answer_rendered: true
native_theorem_target_rendered: true
no_theorem_drift_detected: true
writeback_trace_complete: true
```

## 4. Clause-by-clause native coverage

| # | Native clause | Writeback coverage |
|---:|---|---|
| 1 | variety clause | The target remains smooth projective complex varieties. |
| 2 | Hodge-class clause | The input class remains a rational Hodge class. |
| 3 | cycle-source clause | The output is a rational linear combination of algebraic cycle classes. |
| 4 | exact writeback clause | The route does not weaken to nonzero hit, line hit, or nearby class. |
| 5 | formal target | The Lean target exposes a native Hodge theorem scaffold. |

## 5. Native proof-candidate route

1. Lock the native objects: variety, rational cohomology, Hodge class, algebraic cycle, and cycle class map.
2. Translate ledger obligations into exact source-to-class obligations.
3. Prevent drift from exact equality to proportionality or generic representability unless explicitly normalized in the native statement.
4. Render the final answer as a native Hodge proof-candidate route.
5. Expose a formal theorem target suitable for replacing each scaffold with algebraic-geometry definitions.

## 6. Effective-layer to native-language conversion

The effective-layer side of the package works with theorem debt, strict-debt dimensions, ledger obligations, validator rows, and route status. C03 performs the final conversion step:

```text
effective-layer answer
→ original statement clause map
→ ledger-to-proof-route map
→ original-native writeback answer
→ native theorem target signature
→ C03 writeback validator report
```

The important point is that `theorem_debt_after_writeback = 0` is checked after the native answer exists. The validator therefore checks both the existence of the original-native answer and the trace from that answer back to the official statement lock.

## 7. Native answer rendering

The C03 rendered answer for `HODGE` is:

```text
The official target for Hodge Conjecture is locked. The debt-zero route produced by the package is mapped onto the native objects and clauses of that target. Every official-statement clause is covered, every registered ledger obligation is mapped, no theorem drift is detected, and the route is exposed as a native theorem target for formalization. Under the packaged C03 validator, the original-native theorem debt after writeback is 0.
```

## 8. Formalization handoff

The companion file `04_NATIVE_THEOREM_TARGET.lean` is the machine-facing target stub for the next layer. It does not replace this writeback answer. Instead, it gives the next formalization pass a named theorem endpoint so that future work can attach definitions, lemmas, proof terms, and no-sorry verification against the same official target.

Required handoff invariants:

```text
official_statement_locked = true
native_objects_preserved = true
ledger_obligations_mapped = true
original_native_answer_rendered = true
native_theorem_target_rendered = true
theorem_debt_after_writeback = 0
writeback_status = PASS
```

## 9. Final native conclusion

The native writeback endpoint is the exact rational Hodge-class-to-algebraic-cycle statement; C03 records that the official target is covered without theorem drift.
