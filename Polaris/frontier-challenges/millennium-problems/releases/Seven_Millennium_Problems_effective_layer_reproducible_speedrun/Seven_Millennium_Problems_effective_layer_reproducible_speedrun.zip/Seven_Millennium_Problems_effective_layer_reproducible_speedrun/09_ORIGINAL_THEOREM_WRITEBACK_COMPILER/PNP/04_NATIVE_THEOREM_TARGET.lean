-- C03 native theorem target stub for P vs NP
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.PNP

-- theorem target:
-- Decide whether every efficiently verifiable decision problem is also efficiently solvable.

axiom native_theorem_target_PNP : Prop

end WFGY.C03.PNP
