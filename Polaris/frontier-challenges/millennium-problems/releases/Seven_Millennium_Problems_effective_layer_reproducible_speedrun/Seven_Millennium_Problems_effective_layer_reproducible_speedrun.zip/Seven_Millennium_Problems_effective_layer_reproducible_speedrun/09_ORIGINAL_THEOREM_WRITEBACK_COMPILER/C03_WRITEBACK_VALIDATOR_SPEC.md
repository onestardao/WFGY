# C03 Writeback Validator Spec

## Purpose

The C03 validator checks whether the writeback result is actually tied to the original theorem statement.

It validates the bridge:

```text
effective-layer debt-zero route
-> original-native theorem format
```

## Required checks

For each problem:

1. `official_statement_locked = true`
2. `official_statement_clause_coverage = 100%`
3. `unmapped_official_statement_clauses = 0`
4. `unmapped_ledger_obligations = 0`
5. `theorem_debt_after_writeback = 0`
6. `effective_answer_rendered = true`
7. `native_original_answer_rendered = true`
8. `native_theorem_target_rendered = true`
9. `no_theorem_drift_detected = true`
10. `writeback_status = PASS`

## Package-level pass condition

The package passes C03 only if every problem folder passes all checks.

Expected final line:

```text
ALL7_C03_WRITEBACK_PASS = true
ALL7_original_theorem_writeback_debt = 0
```
