# Poincare Conjecture · Official Statement Lock

## Problem ID

```text
PC
```

## Domain

```text
Geometric topology
```

## Official theorem target

```text
Every closed simply connected three-dimensional manifold is homeomorphic to the three-sphere.
```

## Native target phrase

```text
closed simply connected 3-manifold equals S^3
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
