-- C03 native theorem target stub for Hodge Conjecture
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.HODGE

-- theorem target:
-- Every rational Hodge class on a smooth projective complex variety is a rational linear combination of algebraic cycle classes.

axiom native_theorem_target_HODGE : Prop

end WFGY.C03.HODGE
