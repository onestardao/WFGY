# P vs NP · Official Statement Lock

## Problem ID

```text
PNP
```

## Domain

```text
Computational complexity
```

## Official theorem target

```text
Decide whether every efficiently verifiable decision problem is also efficiently solvable.
```

## Native target phrase

```text
P = NP / P != NP decision problem
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
