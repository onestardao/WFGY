-- C03 native theorem target stub for Yang-Mills Existence and Mass Gap
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.YM

-- theorem target:
-- Construct nontrivial quantum Yang-Mills theory on R^4 for a compact simple gauge group and prove a positive mass gap.

axiom native_theorem_target_YM : Prop

end WFGY.C03.YM
