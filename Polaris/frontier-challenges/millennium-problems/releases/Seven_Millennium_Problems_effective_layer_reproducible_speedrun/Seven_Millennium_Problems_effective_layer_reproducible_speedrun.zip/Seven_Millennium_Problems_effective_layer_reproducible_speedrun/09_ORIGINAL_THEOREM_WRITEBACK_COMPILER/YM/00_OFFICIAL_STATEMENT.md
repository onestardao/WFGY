# Yang-Mills Existence and Mass Gap · Official Statement Lock

## Problem ID

```text
YM
```

## Domain

```text
Mathematical physics
```

## Official theorem target

```text
Construct nontrivial quantum Yang-Mills theory on R^4 for a compact simple gauge group and prove a positive mass gap.
```

## Native target phrase

```text
existence plus positive mass gap
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
