# Compiler Position Audit

C01:
effective-layer input and return-to-original validator.

C02:
effective-layer output / native-spec / ER / formalization-route validator.

F_eff:
effective-layer alignment field.

None of these is imported as bottom sourcefield formula.
