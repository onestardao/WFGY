# No bottom formula import

This package is effective-layer only.

C01/C02/F_eff are treated as external workflow/effective-layer adapters and validators.

This package does not include:
- sourcefield bottom formulas,
- internal first-principle formula core,
- S155/S175 internal proof machinery,
- machine checked Lean files.

S175/S177 are only schema references for strict debt dimensions.
