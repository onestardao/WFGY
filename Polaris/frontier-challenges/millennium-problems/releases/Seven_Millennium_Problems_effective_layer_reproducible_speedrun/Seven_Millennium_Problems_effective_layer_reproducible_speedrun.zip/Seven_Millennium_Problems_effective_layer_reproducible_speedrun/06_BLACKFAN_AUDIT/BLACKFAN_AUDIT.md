# Effective-Layer  Blackfan Audit

Check:
1. Is the package below 500KB?
2. Does it avoid embedding original Seven package?
3. Does it avoid embedding S175/S177?
4. Does it avoid bottom formulas?
5. Does it keep strict debt fields?
6. Does it separate Lean route debt from actual machine-checked file count?
7. Does it preserve reference hashes?
8. Does it remain Codex-runnable as effective-layer review package?

Expected verdict:
PASS if package remains lightweight and effective-layer only.


## Two-way statement validation addendum

Additional blackfan checks for the next package version:

9. Does the package publish only validation data, not the internal compiler engine?
10. Does `10_OFFICIAL_STATEMENT_TWO_WAY_VALIDATION/` contain expanded official-statement payload data for all seven lanes?
11. Does the package include both official-to-native and native-to-official coverage matrices?
12. Does the two-way validator reject statement-tag-only, receipt-only, or theorem-drift cases?
13. Does the public runner print the two-way statement validation status without exposing compiler internals?

Expected verdict:
PASS if the package contains public validation data and validator checks for two-way official statement alignment, while keeping the internal compiler engine private.
