# YM Round 19：Clay 主 Blocker 單核化（Speedrun）
日期：2026-05-20

## 核心目標
把「多個看似分散的 Clay 缺口」收斂成單核義務，避免語意分岔。

## Phase 0
列出 failure states：
1. 有分支排除敘事，沒有 branch-exhaustion 定理。
2. 有 gap 結論敘事，沒有 uniform Delta 提取定理。
3. 有 ER no-sorry 骨架，沒有硬數學閉合物件。

## Phase 1
壓縮為單核 boss：
`YM-Omega* = existence + axioms + branch + Delta` 的聯合閉合義務。

## Phase 2（自指+合一邏輯）
若宣稱已原題完證，但 `YM-Omega*` 未閉合，會與原題要求自撞。
因此只能二選一：
1. 承認未完成；或
2. 補齊 `YM-Omega*` 四段硬證。

本輪結果：採第 1（誠實邊界）並把第 2 任務化。

## Phase 3
輸出為 theorem obligation pack（可追蹤，不再抽象）：
- O1: Existence
- O2: OS/Wightman
- O3: Branch exhaustion
- O4: Uniform Delta

## 本輪判定
- workflow blocker：`CLOSED`
- hard-math blocker：`OPEN_HARD_MATH`

## 進度條
- ER 防禦：🟢🟢🟢🟢🟢
- Clay 單核義務可執行化：🧱🧱🧱🧱⬜
