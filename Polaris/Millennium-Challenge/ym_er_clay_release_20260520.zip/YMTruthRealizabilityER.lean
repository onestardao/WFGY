namespace YMTruthRealizabilityER

structure ERWorld where
  Gap : Prop
  NoGap : Prop
  TargetRelevant : Prop
  Evaluable : Prop
  Physicalizable : Prop
  NonzeroIRResidue : Prop
  BranchClassifiable : Prop
  LegalGaplessSurvivor : Prop

structure ERAssumptions (W : ERWorld) where
  noGap_is_target_or_irrelevant :
    W.NoGap -> W.TargetRelevant \/ W.Gap
  target_relevant_evaluable :
    W.TargetRelevant -> W.Evaluable
  target_relevant_physicalizable :
    W.TargetRelevant -> W.Physicalizable
  no_gap_target_has_residue :
    W.NoGap -> W.TargetRelevant -> W.NonzeroIRResidue
  residue_branch_classifiable :
    W.NonzeroIRResidue -> W.BranchClassifiable
  all_branches_excluded :
    W.BranchClassifiable -> Not W.LegalGaplessSurvivor
  no_gap_yields_survivor :
    W.NoGap -> W.TargetRelevant -> W.BranchClassifiable -> W.LegalGaplessSurvivor
  gap_of_not_no_gap :
    Not W.NoGap -> W.Gap

theorem no_target_relevant_no_gap
    (W : ERWorld)
    (A : ERAssumptions W)
    (hNoGap : W.NoGap)
    (hTarget : W.TargetRelevant) :
    False := by
  have hResidue : W.NonzeroIRResidue :=
    A.no_gap_target_has_residue hNoGap hTarget
  have hBranch : W.BranchClassifiable :=
    A.residue_branch_classifiable hResidue
  have hNoSurvivor : Not W.LegalGaplessSurvivor :=
    A.all_branches_excluded hBranch
  have hSurvivor : W.LegalGaplessSurvivor :=
    A.no_gap_yields_survivor hNoGap hTarget hBranch
  exact hNoSurvivor hSurvivor

theorem gap_from_er_assumptions
    (W : ERWorld)
    (A : ERAssumptions W) :
    W.Gap := by
  by_cases hNoGap : W.NoGap
  · have hTargetOrGap : W.TargetRelevant \/ W.Gap :=
      A.noGap_is_target_or_irrelevant hNoGap
    cases hTargetOrGap with
    | inl hTarget =>
        exact False.elim (no_target_relevant_no_gap W A hNoGap hTarget)
    | inr hGap =>
        exact hGap
  · exact A.gap_of_not_no_gap hNoGap

end YMTruthRealizabilityER
