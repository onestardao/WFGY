# YM Clay-Strict 主 Blocker 補丁清單
日期：2026-05-20

## 主 blocker（按優先序）
1. Existence construction closure
2. OS/Wightman-grade axiomatic closure
3. Branch-exhaustion theorem closure
4. uniform Delta > 0 extractor closure

## 最小可驗收補丁（MVP-Strict）
1. 為每個 compact simple G 明確給出構造對象與可檢核接口。
2. 以 theorem-object 形式列出 OS/Wightman 對應公理與證明依賴。
3. 把 branch table 升成全稱窮盡定理（非敘事表格）。
4. 給出單一 Delta 與 `sigma(H|Omega^perp) subset [Delta, infinity)` 的可審核證明鏈。

## 驗收條件
- 不是只寫「不可能有 gapless 分支」，而是完成定理級排除。
- 不是只寫 ER no-sorry skeleton，而是硬數學段落有外顯定理物件。
- 每個 blocker 都有 `OPEN_HARD_MATH -> CLOSED` 的明確證據轉移。
