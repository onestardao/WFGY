# HODGE Round 04：Clay 主 Blocker 單核化（Speedrun）
日期：2026-05-20

## 核心目標
把 HB1~HB4 從「多點描述」壓成單核義務，對齊 Poincare 的可執行嚴謹度。

## Phase 0
failure states：
1. closure 被誤讀成 target completion。
2. lane closure 難以跨文件重放。
3. referenced-not-included 破壞 fully-contained。

## Phase 1
壓縮為單核 boss：
`HODGE-Omega* = semantic seal + lane replay + descent grade + artifact containment`

## Phase 2（自指+合一邏輯）
若同時宣稱「Clay strict 已完成」且「HB4 非 fully-contained」，語義自撞。
所以只能二選一：
1. 保持誠實邊界；或
2. 補齊 HB4 + 升級 HB3。

本輪結果：採第 1，並把第 2 明確任務化。

## Phase 3
輸出為可驗收義務：
- O1: HB4 fully-contained closure
- O2: HB3 theorem-grade uplift
- O3: unified external replay checklist

## 本輪判定
- workflow blocker：`CLOSED`
- hard closure gap：`OPEN_HARD_MATH / OPEN_STRICT_ARTIFACT`

## 進度條
- ER 防禦：🟢🟢🟢🟢🟢
- Clay 單核義務可執行化：🧱🧱🧱🧱⬜
