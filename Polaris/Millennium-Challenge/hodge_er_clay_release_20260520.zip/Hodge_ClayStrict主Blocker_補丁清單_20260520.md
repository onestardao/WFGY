# Hodge Clay-Strict 主 Blocker 補丁清單
日期：2026-05-20

## 目前狀態
- HB1/HB2/HB3: `MVP_CLOSED`
- HB4: `MVP_CLOSED_WITH_REFERENCE_BOUNDARY`
- 不宣稱：Clay strict 完成、machine-checked 完成

## 主 blocker（按優先序）
1. HB4 fully-contained closure（打包完整性）
2. manual-review grade -> theorem-grade（HB3）
3. Clay strict 外部標準對齊證據（非內部語句閉合）

## 最小可驗收補丁（MVP-Strict）
1. 補齊 `REFERENCED_NOT_INCLUDED` 原始檔，讓 HB4 升為 fully-contained。
2. 將 HB3 的下降台帳轉為機械可核查或至少形式化規格檔。
3. 為 HB1/HB2/HB3/HB4 各補一條外部可否證的 theorem-check 條件。

## 驗收條件
- 不再依賴「聊天上下文」才能重建審查路徑。
- 不再有 reference-boundary 狀態殘留。
- 對外可明確指出：哪一條是內部 closure，哪一條是 Clay 級 closure。
