# HODGE ClayStrict Blocker 佈署 第01輪

日期: 2026-05-20
目標: 從 ER 內部關 gate 升級到 Clay-strict 攻堅模式

## 新 blocker 層（HB1~HB4）

### HB1: 外部語義等價封印 blocker

要求:
- 將內部 theorem-chain 語義與「原始 Hodge 目標」做雙向等價封印，
- 並防止 proof-state closure 被誤讀成 target closure。

### HB2: 載體窮盡與通道全覆蓋 blocker

要求:
- 對 S/H/P/C 的窮盡與每通道 closure，給出可逐條審核的完整索引與反例門檻。

### HB3: K-嚴格下降可檢核 blocker

要求:
- 每個宣稱 strict descent 的步驟都要對應到 K 分量下降，
- 形成 reviewer 可重放的下降台帳。

### HB4: 封裝可重建與跨機路徑 blocker

要求:
- 把目前 `/mnt/data/...` 類路徑改成可移植 manifest 表達，
- 完成「檔案在、hash 在、依賴圖在、重放說明在」的一致包。

## speedrun phase 路線

Phase 0:
- 每個 HB 拆成 failure-state 清單（可被攻擊的具體點）。

Phase 1:
- 壓縮成單一 super-boss：
  `hodge_clay_strict_equivalence_boss`。

Phase 2:
- 一次打一個 HB，採反證模板，輸出 theorem debt packet。

Phase 3:
- 把已打穿的 HB 變成 ER 附錄與主鏈索引，不留語意黑洞。

## 回合估計（從現在起）

- MVP 強化（可明顯更耐打）: 3-6 回合
- Clay-strict 攻堅版: 12-30 回合

說明:
這是 workflow 估計，不是保證。若某 HB 出現新外部反例，回合會上升。

