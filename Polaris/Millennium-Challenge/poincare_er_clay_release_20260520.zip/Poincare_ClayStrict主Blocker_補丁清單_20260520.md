# Poincare Clay-Strict 主 Blocker 補丁清單
日期：2026-05-20

## 目前狀態
- ER 宣告標準：完成
- 最大 blocker：已收斂為 `T-Omega` / `T-Omega-MC` 任務化義務
- 未完成：machine-checked no-sorry 等級

## 主 blocker（按優先序）
1. T-Omega 的 machine-checkable formalization
2. source-reconstruction 到 theorem-object 的嚴格映射
3. higher-bar external reproducibility（非僅流程回放）

## 最小可驗收補丁（MVP-Strict）
1. 將 T-Omega 的 entry/conservation/terminus 三段落地為形式化 lemma 介面。
2. 明確標出每段依賴來源與可替代性條件。
3. 補一份 no-sorry 範圍聲明：哪些已 formal、哪些仍 external theorem import。

## 驗收條件
- 「ER 完成」與「machine-checked 完成」不混寫。
- T-Omega 不只存在為敘事義務，而是可執行驗證物件。
- 外部 reviewer 可在不讀聊天記憶下重放核心判定。
